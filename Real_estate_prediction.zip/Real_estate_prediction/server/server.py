# from flask import Flask, request, jsonify
# import util

# app = Flask(__name__)


# @app.route('/get_location_names', methods=['GET'])
# def get_location_names():
#     response = jsonify({
#         'locations': util.get_location_names()
#     })
#     response.headers.add('Access-Control-Allow-Origin', '*')

#     return response


# @app.route('/predict_home_price', methods=['GET', 'POST'])
# def predict_home_price():
#     crim = float(request.form['crim'])
#     rm = request.form['rm']
#     lstat = int(request.form['lstat'])
#     nox = int(request.form['nox'])
#     ptratio = int(request.form['ptratio'])

#     response = jsonify({
#         'estimated_price': util.get_estimated_price(crim, rm, lstat, nox, ptratio)
#     })
#     response.headers.add('Access-Control-Allow-Origin', '*')

#     return response


# if __name__ == "__main__":
#     print("Starting Python Flask Server For Home Price Prediction...")
#     util.load_saved_artifacts()
#     app.run()


from flask import Flask, request, jsonify
# from flask_cors import CORS  # Add this import
import util

app = Flask(__name__)
# CORS(app)  # Proper CORS handling


@app.route('/get_location_names', methods=['GET'])
def get_location_names():
    try:
        response = jsonify({
            'locations': util.get_location_names()
        })
        return response
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predict_risk', methods=['POST'])  # Changed endpoint name
def predict_risk():
    try:
        # Get and validate all parameters
        data = request.get_json() if request.is_json else request.form

        crim = float(data.get('crim'))
        rm = float(data.get('rm'))  # Convert to float
        lstat = float(data.get('lstat'))  # Changed to float
        nox = float(data.get('nox'))  # Changed to float
        ptratio = float(data.get('ptratio'))  # Changed to float

        # Call your util function (you may need to modify this)
        risk_score = util.calculate_risk(crim, rm, lstat, nox, ptratio)

        # Determine risk level
        if risk_score < 1.5:
            risk_level = "low"
        elif risk_score < 3:
            risk_level = "medium"
        else:
            risk_level = "high"

        return jsonify({
            'risk_score': risk_score,
            'risk_level': risk_level,
            'message': f'The real estate has {risk_level} risk to buy.'
        })

    except ValueError as e:
        return jsonify({'error': 'Invalid numeric value provided'}), 400
    except KeyError as e:
        return jsonify({'error': f'Missing parameter: {str(e)}'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == "__main__":
    print("Starting Python Flask Server For Real Estate Risk Prediction...")
    util.load_saved_artifacts()
    app.run(debug=True)  # Added debug mode for development
