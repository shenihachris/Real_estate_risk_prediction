# import pickle
# import json
# import numpy as np

# __locations = None
# __data_columns = None
# __model = None


# def get_estimated_price(crim, rm, lstat, nox, ptratio):
#     try:
#         loc_index = __data_columns.index(location.lower())
#     except:
#         loc_index = -1

#     x = np.zeros(len(__data_columns))
#     x[0] = crim
#     x[1] = rm
#     x[2] = lstat
#     x[3] = nox
#     x[4] = ptratio
#     if loc_index >= 0:
#         x[loc_index] = 1

#     return round(__model.predict([x])[0], 4)


# def load_saved_artifacts():
#     print("loading saved artifacts...start")
#     global __data_columns
#     global __locations

#     with open("./artifacts/columns.json", "r") as f:
#         __data_columns = json.load(f)['data_columns']
#         # first 3 columns are crim,rm,lstat,nox,ptratio
#         __locations = __data_columns[5:]

#     global __model
#     if __model is None:
#         with open('./artifacts/banglore_home_prices_model.pickle', 'rb') as f:
#             __model = pickle.load(f)
#     print("loading saved artifacts...done")


# def get_location_names():
#     return __locations


# def get_data_columns():
#     return __data_columns


# if __name__ == '__main__':
#     load_saved_artifacts()
#     print(get_location_names())
#     print(get_estimated_price(0.1, 7.5, 5.0, 0.4, 14.0))
#     print(get_estimated_price(0.8, 6.2, 12.0, 0.5, 18.0))
#     print(get_estimated_price(18.0, 4.8, 22.0, 0.7, 20.0))  # other location
#     print(get_estimated_price(0.5, 6.5, 10.0, 0.5, 18.0))  # other location

import pickle
import numpy as np

# Define the feature columns directly in code
__data_columns = ['crim', 'rm', 'lstat', 'nox', 'ptratio']
__model = None


def calculate_risk(crim, rm, lstat, nox, ptratio):
    """Calculate real estate risk based on input parameters"""
    try:
        # Create input array with the 5 features in the correct order
        x = np.array([[crim, rm, lstat, nox, ptratio]])

        # Get prediction from model
        risk_score = __model.predict(x)[0]

        return risk_score

    except Exception as e:
        print(f"Error in calculate_risk: {str(e)}")
        raise e


def load_saved_artifacts():
    print("loading saved artifacts...start")
    global __model

    # Load model directly (assuming it's in the same directory)
    model_path = 'rsp.pickle'
    try:
        with open(model_path, 'rb') as f:
            __model = pickle.load(f)
        print(f"Model loaded successfully from {model_path}")
    except FileNotFoundError:
        print(f"Error: Model file not found at {model_path}")
        raise
    except Exception as e:
        print(f"Error loading model: {str(e)}")
        raise

    print("loading saved artifacts...done")


def get_feature_columns():
    """Return the feature columns in order"""
    return __data_columns


if __name__ == '__main__':
    # Test the risk calculation
    load_saved_artifacts()
    print("Feature columns:", get_feature_columns())
    print("Sample risk predictions:")
    print(calculate_risk(0.1, 7.5, 5.0, 0.4, 14.0))  # Should return low risk
    print(calculate_risk(0.8, 6.2, 12.0, 0.5, 18.0))  # Medium risk
    print(calculate_risk(18.0, 4.8, 22.0, 0.7, 20.0))  # High risk
